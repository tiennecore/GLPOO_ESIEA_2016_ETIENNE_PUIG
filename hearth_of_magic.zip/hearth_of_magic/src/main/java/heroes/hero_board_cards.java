package heroes;

public class hero_board_cards extends hero {
	private int attack;
	
	private int defence;
	
	private int provocation;
	
	

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public int getDefence() {
		return defence;
	}

	public void setDefence(int defence) {
		this.defence = defence;
	}

	public int getProvocation() {
		return provocation;
	}

	public void setProvocation(int provocation) {
		this.provocation = provocation;
	}

}
