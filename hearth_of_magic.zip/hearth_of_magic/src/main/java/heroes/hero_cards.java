package heroes;

import java.util.ArrayList;

public class hero_cards extends hero {
	
	private int attack;
	
	private int defence;
	
	private int provocation;
	
	private ArrayList<Integer> position=new ArrayList<Integer>(2);
	
	private int price_card;
	
	public void hero_position()
	{
		for (int i=0;i< 2 ; i++)
		{
			position.set(i,0);			
		}
	}
	
	
	public int getAttack() {
		return attack;
	}
	public void setAttack(int attack) {
		this.attack = attack;
	}
	public int getDefence() {
		return defence;
	}
	public void setDefence(int defence) {
		this.defence = defence;
	}
	
	public int getProvocation() {
		return provocation;
	}
	public void setProvocation(int provocation) {
		this.provocation = provocation;
	}
	public int getPrice_card() {
		return price_card;
	}
	public void setPrice_card(int price_card) {
		this.price_card = price_card;
	}
	

}
