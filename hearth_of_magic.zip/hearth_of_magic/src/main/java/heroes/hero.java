package heroes;

import java.util.ArrayList;

public class hero {

	public static String nameHero;

	public static int powerHero;

	public static int defenceHero;

	public static int lifeHero;
	
	public static int typeHero;

	public static ArrayList<Integer> cristals= new ArrayList<Integer> (10);
	
	public static hero_cards cards_id = new hero_cards();
	
	public static hero_board_cards cards_put_id = new hero_board_cards();
	
	public static ArrayList<Integer> cards_hand= new ArrayList<Integer> (10);
	
	public static ArrayList<Integer> cards_put=new ArrayList<Integer>(6);
	
	
	public void INIT_CARDS_HERO()
	{
		for (int i=0;i<10;i++)
		{
			cards_hand.set(i, null);
		}
		for (int i=0;i<6;i++)
		{
			cards_put.set(i, null);
		}
	}
	
	
	
	
	
	
	
	public String getNameHero() {
		return nameHero;
	}

	public void setNameHero(String nameHero) {
		hero.nameHero = nameHero;
	}

	public int getPowerHero() {
		return powerHero;
	}

	public void setPowerHero(int powerHero) {
		hero.powerHero = powerHero;
	}

	public int getDefenceHero() {
		return defenceHero;
	}

	public void setDefenceHero(int defenceHero) {
		hero.defenceHero = defenceHero;
	}

	public int getLifeHero() {
		return lifeHero;
	}

	public void setLifeHero(int lifeHero) {
		hero.lifeHero = lifeHero;
	}

	public int getTypeHero() {
		return typeHero;
	}

	public void setTypeHero(int typeHero) {
		hero.typeHero = typeHero;
	}






	public ArrayList<Integer> getCristals() {
		return cristals;
	}






	public void setCristals(ArrayList<Integer> cristals) {
		hero.cristals = cristals;
	}

}
