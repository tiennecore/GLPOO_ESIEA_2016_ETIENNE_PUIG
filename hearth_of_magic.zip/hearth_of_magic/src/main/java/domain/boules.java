package domain;

public class boules {
	private String boule_id_1;
	private String boule_id_2;
	
	public boules(String boule_id_1, String boule_id_2)
	{
		super();
		this.boule_id_1=boule_id_1;
		this.boule_id_2=boule_id_2;
	}
	
	
	
	public String getBoule_id_1() {
		return boule_id_1;
	}
	public void setBoule_id_1(String boule_id_1) {
		this.boule_id_1 = boule_id_1;
	}
	public String getBoule_id_2() {
		return boule_id_2;
	}
	public void setBoule_id_2(String boule_id_2) {
		this.boule_id_2 = boule_id_2;
	}
	

}
