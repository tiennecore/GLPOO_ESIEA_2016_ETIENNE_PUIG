package data_euro;

import java.util.List;
import domain.boules;

public interface euro {
	List<boules> findBoules();

}
