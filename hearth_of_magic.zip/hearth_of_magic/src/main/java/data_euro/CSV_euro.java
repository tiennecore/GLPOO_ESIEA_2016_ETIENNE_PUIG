package data_euro;



import java.util.List;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import data_euro.euro;
import data.CSV_READ;
import domain.boules;

public class CSV_euro implements euro{

	private final static char SEPARATOR = ';';
	private final static String RESOURCES_PATH = "src/main/resources/";
	private final static String BOULES_FILE_NAME = "euromillions_3.csv";
	
	public List<boules> findBoules() {

		final List<String[]> data = readCsvFile(RESOURCES_PATH + BOULES_FILE_NAME, SEPARATOR);

		final List<boules> BOULES = dataToBoules(data);

		return BOULES;
	}

	private List<boules> dataToBoules(List<String[]> data) {
		final List<boules> BOULES = new ArrayList<boules>();

		try {
			for (String[] oneData : data) {
				
				final String boule_id_1 = oneData[4];
				final String boule_id_2 = oneData[5];
				

				final Integer boule_1 = Integer.parseInt(boule_id_1);
				
				final Integer boule_2 = Integer.parseInt(boule_id_2);
				

				final boules propriety_mouvement = new boules(boule_id_1,boule_id_2);
				BOULES.add(propriety_mouvement);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return BOULES;
	}
}
