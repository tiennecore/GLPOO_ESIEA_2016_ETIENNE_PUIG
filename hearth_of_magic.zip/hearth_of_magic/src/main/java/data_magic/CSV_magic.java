package data_magic;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import domain.card_id;

public class CSV_magic {
	
	private final static char SEPARATOR = ';';
	private final static String RESOURCES_PATH = "src/main/resources/";
	private final static String MAGIC_FILE_NAME = "list_card.csv";
	
	public List<card_id> findBoules() {

		final List<String[]> data = readCsvFile(RESOURCES_PATH + MAGIC_FILE_NAME, SEPARATOR);

		final List<card_id> card_propriety = dataToMagic(data);

		return card_propriety;
	}

	private List<card_id> dataToMagic(List<String[]> data) {
		final List<card_id> card_propriety = new ArrayList<card_id>();

		try {
			for (String[] oneData : data) {
				
				final String name = oneData[0];
				final String type = oneData[1];

				final card_id propriety_cards = new card_id(name,type);
				card_propriety.add(propriety_cards);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return card_propriety;
	}

}
