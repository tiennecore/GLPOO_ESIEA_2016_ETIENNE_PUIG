package data_magic;

import java.util.List;

import domain.card_id;

public interface magic {
	
	List<card_id> findMagic();
}
