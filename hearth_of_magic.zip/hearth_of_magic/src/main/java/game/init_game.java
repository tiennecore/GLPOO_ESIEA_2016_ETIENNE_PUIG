package game;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

import heroes.hero;

public class init_game extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void init_cards()
	{
		for (int i=0;i<4;i++)
		{
			hero.cards_hand.set(i,1);
		}
	}/*
	public void paint(Graphics INIT_GAME)
	{
		INIT_GAME.setColor(Color.blue);
		INIT_GAME.fillOval( 26, 185, 10, 10);
	}*/
	
	

}
