package game;

import java.util.ArrayList;

public class principale_game {
	private ArrayList<Integer> heroes =new ArrayList<Integer>(2);

	public ArrayList<Integer> getHeroes() {
		return heroes;
	}

	public void setHeroes(ArrayList<Integer> heroes) {
		this.heroes = heroes;
	}

}
