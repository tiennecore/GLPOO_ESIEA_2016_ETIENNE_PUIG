package board;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class compartments extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BufferedImage img1;
	public compartments(){
		super();
		try {
			img1 = ImageIO.read(new File("src/main/java/image/image_board2.png"));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void paint(Graphics INIT_BOARD) {
		
		INIT_BOARD.setColor(Color.BLACK);
		INIT_BOARD.fillRect(295, 162, 660, 165);
		INIT_BOARD.fillRect(45, 332, 660, 165);

		
		/*
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 5; j++) {
				if (j == 0) {
					INIT_BOARD.drawImage(img1, i*100, 0,99,160, null); 
					
				}
				if (j == 3) {
					INIT_BOARD.drawImage(img1, i*100, 500, 99, 160, null);
				}
				if (j == 2) {
					
					//INIT_BOARD.fillRect(295, 162, 660, 165);
					//INIT_BOARD.fillRect(45, 332, 660, 165);
					if (i<6)
					{
						INIT_BOARD.drawImage(img1, 300+i*100, 165, 99, 160, null);
						INIT_BOARD.drawImage(img1, 50+i*100, 335, 99, 160, null);
					}
				}
				if (j == 1) {
					INIT_BOARD.setColor(Color.BLACK);
					if (i < 5) {
						INIT_BOARD.fillOval(150 + i * 26, 185, 10, 10);
						INIT_BOARD.fillOval(730 + i * 26, 355, 10, 10);

					} else {
						INIT_BOARD.fillOval(150 + (i - 5) * 26, 220, 10, 10);
						INIT_BOARD.fillOval(730 + (i - 5) * 26, 390, 10, 10);
					}

				}

			}
		}*/
		
		
	}

	
}
