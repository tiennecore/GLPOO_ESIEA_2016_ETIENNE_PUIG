package cards_id;

import java.util.ArrayList;

public class cards {
	public static ArrayList<Integer> all_cards=new ArrayList<Integer>(150);
	
	public void give_propriety()
	{
		for (int h=0;h<150;h++)
		{
			all_cards.set(h, null);
		}
	}
	
}
