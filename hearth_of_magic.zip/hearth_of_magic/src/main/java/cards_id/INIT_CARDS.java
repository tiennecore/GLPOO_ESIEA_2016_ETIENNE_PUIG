package cards_id;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import data_euro.CSV_euro;
import data_euro.euro;
import domain.boules;



public class INIT_CARDS {
	
	private int attack;
	
	private int defence;
	
	private int placement;
	
	private int provocation;
	
	private int price_card;
	
	final euro mouvement = new CSV_euro();
	final List<boules> BOULES = euro.findBoules();
	
	public void take_mouvement()
	{
		Random rand = new Random();
		int i = size(boules[][]);
		placement=rand.nextInt(i);
		attack=boules[i][];
		defence=boules[][i];
		provocation=rand.nextInt(1/i);
		
		for (int j=1;j<6;j++)
		{
			if (defence>9 && defence<=i*10)
			{
				defence=defence-i*10;
			}
			if (attack>9 && attack<=i*10)
			{
				attack=attack-i*10;
			}
		}
	}
	public void INIT_PIECE_CARD()
	{
		if((attack+defence)<4)
		{
			price_card=1;
		}
		if((attack+defence)>3 && (attack+defence)<6 )
		{
			price_card=2;
		}
		if((attack+defence)>5 && (attack+defence)<7 )
		{
			price_card=3;
		}
		if((attack+defence)>6 && (attack+defence)<8 )
		{
			price_card=4;
		}
		if((attack+defence)>7 && (attack+defence)<10 )
		{
			price_card=5;
		}
		if((attack+defence)>9 && (attack+defence)<13 )
		{
			price_card=6;
		}
		if((attack+defence)>12 && (attack+defence)<14 )
		{
			price_card=7;
		}
		if((attack+defence)>13 && (attack+defence)<18 )
		{
			price_card=8;
		}
		if((attack+defence)>17 && (attack+defence)<19 )
		{
			price_card=9;
		}
	}
	
	
	
	
	
	
	
	
	
	

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public int getDefence() {
		return defence;
	}

	public void setDefence(int defence) {
		this.defence = defence;
	}

	public int getProvocation() {
		return provocation;
	}

	public void setProvocation(int provocation) {
		this.provocation = provocation;
	}

	public ArrayList<Integer> getPosition() {
		return position;
	}

	public void setPosition(ArrayList<Integer> position) {
		this.position = position;
	}

	public int getPrice_card() {
		return price_card;
	}

	public void setPrice_card(int price_card) {
		this.price_card = price_card;
	}

}
