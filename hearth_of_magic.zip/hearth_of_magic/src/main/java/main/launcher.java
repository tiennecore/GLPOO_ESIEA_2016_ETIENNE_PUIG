package main;

import main.window;

public class launcher {
	public static void main(String[] args) {
		final window window_main = new window();
		window_main.setVisible(true);
	}

}
