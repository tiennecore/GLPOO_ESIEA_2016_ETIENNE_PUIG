package main;


import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import board.compartments;


public class window extends JFrame {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	
	

	private  JPanel pistache=new JPanel();
	public void initpistache(){
		pistache.setLayout(new FlowLayout(FlowLayout.CENTER));		
		pistache.add(new compartments());	
	}
	
	
	
	public window() {
		
		this.setTitle("heart of magic");
		this.setSize(1000, 660);
		this.setResizable(false); 
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.add(pistache);
		//init_game intiat = new init_game();
		//this.setContentPane(intiat);
		
		//this.setContentPane(new compartments());

	}

}
